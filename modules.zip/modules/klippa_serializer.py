def _is_year_cell(content):
    value = (content or "").strip()
    return value.isdigit() and len(value) == 4


def _row_contains_header_terms(row):
    text = " ".join(row).lower()
    return any(
        term in text
        for term in [
            "nota explicativa",
            "nota",
            "controladora",
            "consolidado",
            "individual",
        ]
    )


def _is_header_row(matrix, row_index):
    if row_index >= 2:
        return False

    row = matrix[row_index]

    if row_index == 0:
        return _row_contains_header_terms(row) or any(cell.strip() for cell in row)

    return sum(1 for cell in row if _is_year_cell(cell)) >= 2


def serialize_matrix_to_klippa_table(
    matrix,
    document_index=0,
):
    """
    Serialize a visual matrix to the Klippa table shape.

    Header rows are inferred from the normalized matrix. Klippa commonly marks
    the label/group header row and the year row as headers.
    """

    cells = []

    row_count = len(matrix)
    column_count = max((len(row) for row in matrix), default=0)

    for row_index, row in enumerate(matrix):
        is_header = _is_header_row(matrix, row_index)

        for column_index in range(column_count):
            content = row[column_index] if column_index < len(row) else ""

            cells.append(
                {
                    "row_index": row_index,
                    "column_index": column_index,
                    "content": content,
                    "header": is_header,
                }
            )

    return {
        "document": document_index,
        "row_count": row_count,
        "column_count": column_count,
        "cells": cells,
    }



def serialize_klippa_result(tables, text_content=None, version="1"):
    """Build the full Klippa-compatible OCR result envelope.

    Shape:
    {
        "ocr_result_klippa": {
            "version": "1",
            "components": {
                "tables": {
                    "tables": [...],
                    "text_content": [...]
                }
            }
        }
    }

    ``tables`` must already be serialized Klippa-style table dictionaries.
    ``text_content`` is a list of extracted page text strings. It defaults to
    an empty list to keep the key present even when text extraction was not
    supplied by the caller.
    """

    if text_content is None:
        text_content = []

    return {
        "ocr_result_klippa": {
            "version": version,
            "components": {
                "tables": {
                    "tables": tables,
                    "text_content": text_content,
                }
            },
        }
    }


def attach_text_content_to_klippa_result(result, text_content):
    """Add components.tables.text_content to an existing result in place.

    This helper is useful for existing pipeline code that already creates the
    result envelope manually. It preserves all current table data and only adds
    or replaces the text_content sibling key.
    """

    root = result.setdefault("ocr_result_klippa", {})
    root.setdefault("version", "1")
    components = root.setdefault("components", {})
    tables_component = components.setdefault("tables", {})
    tables_component.setdefault("tables", [])
    tables_component["text_content"] = text_content or []
    return result
